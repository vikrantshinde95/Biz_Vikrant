create schema silver_db;

create table silver_db.salary_silver (
salary_id int unique,
employee_name varchar(50),
job_title varchar(50),
department_name varchar(50),
salary_amount decimal(10,2),
total_monthly_salary decimal(10,2),
yearly_salary decimal(10,2),
salary_category decimal(10,2),
salary_date date,
processed_date date
);

select * from silver_db.salary_silver


create table silver_db.employee_silver(
employee_name varchar(50),
job_title varchar(50)
);

select * from silver_db.employee_silver

create table silver_db.department_silver(
department_name varchar(50)
);


select * from silver_db.department_silver

---operations performed on silver layer data---

-- Department wise salary

select s.department_name,
		sum(s.salary_amount) as total_salary_value,
		avg(salary_amount) as average_salary,
		getDate() as report_date  
from silver_db.salary_silver as s
join [silver_db].[department_silver] as d 
on s.department_name = d.department_name
group by s.department_name;


--- Analysis On employee salary

select s.*,
		sum(s.salary_amount) over (partition by e.employee_name) as employeewise_salary
from [silver_db].[salary_silver] s,
[silver_db].[employee_silver] e
where s.employee_name = e.employee_name;


create schema gold_db;

create table salary_gold(
				department_name varchar(50),
				total_salary_value decimal,
				avg_salary decimal,
				report_date date
     );

--- Inserting Values in salary_gold table

insert into salary_gold (department_name,total_salary_value,avg_salary,report_date)

select s.department_name,
		sum(s.salary_amount) as total_salary_value,
		avg(salary_amount) as average_salary,
		getDate() as report_date  
from silver_db.salary_silver as s
join [silver_db].[department_silver] as d on s.department_name = d.department_name
group by s.department_name

select * from�dbo.salary_gold