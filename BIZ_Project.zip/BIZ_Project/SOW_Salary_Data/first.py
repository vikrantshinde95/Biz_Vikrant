import pyspark

from pyspark.sql import SparkSession



spark = SparkSession.builder.appName("ExampleApp").getOrCreate()# Create SparkSession
data = [(101,"vikrant"),(102,"suraj")]

columns = ["id","name"]

df = spark.createDataFrame(data=data,schema=columns)
df.show()